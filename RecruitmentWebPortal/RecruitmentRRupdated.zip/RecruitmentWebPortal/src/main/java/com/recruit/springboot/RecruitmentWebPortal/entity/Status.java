package com.recruit.springboot.RecruitmentWebPortal.entity;

public enum Status {
    PROFILE_SHARED,
    MEETING_LINK_SHARED,
    YET_TO_RECEIVE_UPDATED_CV
}
