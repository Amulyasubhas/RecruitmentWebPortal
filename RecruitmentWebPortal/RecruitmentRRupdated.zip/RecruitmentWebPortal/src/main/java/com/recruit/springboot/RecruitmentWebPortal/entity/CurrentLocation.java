package com.recruit.springboot.RecruitmentWebPortal.entity;

public enum CurrentLocation {
    BANGALORE,
    UDUPI,
    MUMBAI,
    CHENNAI
}
