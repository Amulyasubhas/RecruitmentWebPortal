package com.recruit.springboot.RecruitmentWebPortal.entity;

public enum Priority {
    HIGH,
    MEDIUM,
    LOW
}
