package com.recruit.springboot.RecruitmentWebPortal.DTO;
public class ForgotPasswordDTO {
    private String email;
    

    // Getters and Setters

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }


}


