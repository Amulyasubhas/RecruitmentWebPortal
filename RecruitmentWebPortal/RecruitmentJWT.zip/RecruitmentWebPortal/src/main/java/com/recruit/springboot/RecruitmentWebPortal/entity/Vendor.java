package com.recruit.springboot.RecruitmentWebPortal.entity;

public enum Vendor {
    NA
}
