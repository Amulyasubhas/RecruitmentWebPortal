package com.recruit.springboot.RecruitmentWebPortal.entity;

public enum Recruiter {
    MISHEL,
    SHARATH,
    SHILPA,
    CHINMAY
}
