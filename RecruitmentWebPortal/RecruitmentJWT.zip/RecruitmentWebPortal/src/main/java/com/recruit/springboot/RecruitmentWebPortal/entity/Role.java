package com.recruit.springboot.RecruitmentWebPortal.entity;

public enum Role {
    ADMIN,
    RECRUITER,
    HR,
    CANDIDATE
}
