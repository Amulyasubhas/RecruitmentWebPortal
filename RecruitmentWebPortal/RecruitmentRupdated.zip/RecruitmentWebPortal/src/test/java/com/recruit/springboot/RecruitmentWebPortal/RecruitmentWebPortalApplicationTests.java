package com.recruit.springboot.RecruitmentWebPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecruitmentWebPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
