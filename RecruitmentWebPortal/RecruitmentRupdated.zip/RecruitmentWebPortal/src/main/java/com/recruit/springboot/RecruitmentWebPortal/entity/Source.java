package com.recruit.springboot.RecruitmentWebPortal.entity;

public enum Source {
    LINKEDIN,
    REFERENCE
}
