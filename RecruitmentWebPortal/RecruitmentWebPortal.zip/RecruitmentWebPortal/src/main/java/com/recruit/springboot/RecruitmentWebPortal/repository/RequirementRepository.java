package com.recruit.springboot.RecruitmentWebPortal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.recruit.springboot.RecruitmentWebPortal.entity.Requirement;

public interface RequirementRepository extends JpaRepository<Requirement, Long> {
}
