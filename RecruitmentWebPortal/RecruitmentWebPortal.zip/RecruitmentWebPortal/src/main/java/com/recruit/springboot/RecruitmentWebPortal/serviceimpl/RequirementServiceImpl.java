package com.recruit.springboot.RecruitmentWebPortal.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.recruit.springboot.RecruitmentWebPortal.DTO.RequirementDTO;
import com.recruit.springboot.RecruitmentWebPortal.entity.Requirement;
import com.recruit.springboot.RecruitmentWebPortal.repository.RequirementRepository;
import com.recruit.springboot.RecruitmentWebPortal.service.RequirementService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RequirementServiceImpl implements RequirementService {

    @Autowired
    private RequirementRepository repository;

    private RequirementDTO mapToDTO(Requirement req) {
        return new RequirementDTO(
                req.getId(), req.getRole(), req.getNumberOfPositions(),
                req.getSkills(), req.getYearsOfExperience(), req.getClientName(),
                req.getBudget(), req.getLocation(), req.getWorkTimings(),
                req.getPriority(), req.getPositionStatus()
        );
    }

    private Requirement mapToEntity(RequirementDTO dto) {
        return new Requirement(
                dto.getId(), dto.getRole(), dto.getNumberOfPositions(),
                dto.getSkills(), dto.getYearsOfExperience(), dto.getClientName(),
                dto.getBudget(), dto.getLocation(), dto.getWorkTimings(),
                dto.getPriority(), dto.getPositionStatus()
        );
    }

    @Override
    public RequirementDTO createRequirement(RequirementDTO dto) {
        Requirement req = mapToEntity(dto);
        return mapToDTO(repository.save(req));
    }

    @Override
    public List<RequirementDTO> getAllRequirements() {
        return repository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Override
    public RequirementDTO getRequirementById(Long id) {
        return repository.findById(id)
                .map(this::mapToDTO)
                .orElseThrow(() -> new RuntimeException("Requirement not found"));
    }

    @Override
    public RequirementDTO updateRequirement(Long id, RequirementDTO dto) {
        Requirement existing = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Requirement not found"));

        existing.setRole(dto.getRole());
        existing.setNumberOfPositions(dto.getNumberOfPositions());
        existing.setSkills(dto.getSkills());
        existing.setYearsOfExperience(dto.getYearsOfExperience());
        existing.setClientName(dto.getClientName());
        existing.setBudget(dto.getBudget());
        existing.setLocation(dto.getLocation());
        existing.setWorkTimings(dto.getWorkTimings());
        existing.setPriority(dto.getPriority());
        existing.setPositionStatus(dto.getPositionStatus());

        return mapToDTO(repository.save(existing));
    }

    @Override
    public void deleteRequirement(Long id) {
        repository.deleteById(id);
    }
}
