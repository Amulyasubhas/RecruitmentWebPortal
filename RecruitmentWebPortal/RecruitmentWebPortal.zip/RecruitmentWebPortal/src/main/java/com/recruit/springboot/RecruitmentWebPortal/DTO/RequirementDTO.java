package com.recruit.springboot.RecruitmentWebPortal.DTO;

public class RequirementDTO {

    private Long id;
    private String role;
    private int numberOfPositions;
    private String skills;
    private int yearsOfExperience;
    private String clientName;
    private double budget;
    private String location;
    private String workTimings;
    private String priority;
    private String positionStatus;

    public RequirementDTO() {
    }

    public RequirementDTO(Long id, String role, int numberOfPositions, String skills, int yearsOfExperience,
                          String clientName, double budget, String location, String workTimings,
                          String priority, String positionStatus) {
        this.id = id;
        this.role = role;
        this.numberOfPositions = numberOfPositions;
        this.skills = skills;
        this.yearsOfExperience = yearsOfExperience;
        this.clientName = clientName;
        this.budget = budget;
        this.location = location;
        this.workTimings = workTimings;
        this.priority = priority;
        this.positionStatus = positionStatus;
    }

    // Getters and Setters

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public int getNumberOfPositions() { return numberOfPositions; }
    public void setNumberOfPositions(int numberOfPositions) { this.numberOfPositions = numberOfPositions; }

    public String getSkills() { return skills; }
    public void setSkills(String skills) { this.skills = skills; }

    public int getYearsOfExperience() { return yearsOfExperience; }
    public void setYearsOfExperience(int yearsOfExperience) { this.yearsOfExperience = yearsOfExperience; }

    public String getClientName() { return clientName; }
    public void setClientName(String clientName) { this.clientName = clientName; }

    public double getBudget() { return budget; }
    public void setBudget(double budget) { this.budget = budget; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getWorkTimings() { return workTimings; }
    public void setWorkTimings(String workTimings) { this.workTimings = workTimings; }

    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }

    public String getPositionStatus() { return positionStatus; }
    public void setPositionStatus(String positionStatus) { this.positionStatus = positionStatus; }
}
