package com.recruit.springboot.RecruitmentWebPortal.entity;

public @interface Data {

}
