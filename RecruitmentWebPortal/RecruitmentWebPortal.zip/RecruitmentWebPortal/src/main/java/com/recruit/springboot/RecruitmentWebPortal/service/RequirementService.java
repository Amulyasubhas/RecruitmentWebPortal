package com.recruit.springboot.RecruitmentWebPortal.service;

import java.util.List;

import com.recruit.springboot.RecruitmentWebPortal.DTO.RequirementDTO;

public interface RequirementService {
    RequirementDTO createRequirement(RequirementDTO dto);
    List<RequirementDTO> getAllRequirements();
    RequirementDTO getRequirementById(Long id);
    RequirementDTO updateRequirement(Long id, RequirementDTO dto);
    void deleteRequirement(Long id);
}
