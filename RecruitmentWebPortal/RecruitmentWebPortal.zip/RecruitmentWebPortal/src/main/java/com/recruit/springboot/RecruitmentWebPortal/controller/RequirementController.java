package com.recruit.springboot.RecruitmentWebPortal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.recruit.springboot.RecruitmentWebPortal.DTO.RequirementDTO;
import com.recruit.springboot.RecruitmentWebPortal.service.RequirementService;

import java.util.List;

@RestController
@RequestMapping("/api/requirements")
public class RequirementController {

    @Autowired
    private RequirementService service;

    @PostMapping
    public RequirementDTO create(@RequestBody RequirementDTO dto) {
        return service.createRequirement(dto);
    }

    @GetMapping
    public List<RequirementDTO> getAll() {
        return service.getAllRequirements();
    }

    @GetMapping("/{id}")
    public RequirementDTO getById(@PathVariable Long id) {
        return service.getRequirementById(id);
    }

    @PutMapping("/{id}")
    public RequirementDTO update(@PathVariable Long id, @RequestBody RequirementDTO dto) {
        return service.updateRequirement(id, dto);
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        service.deleteRequirement(id);
        return "Requirement deleted";
    }
}
