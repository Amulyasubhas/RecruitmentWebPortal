package com.recruit.springboot.RecruitmentWebPortal.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.recruit.springboot.RecruitmentWebPortal.DTO.EmployeeDTO;

import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<EmployeeDTO, Long> {
    Optional<EmployeeDTO> findByEmail(String email);
}
