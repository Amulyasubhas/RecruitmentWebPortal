package com.recruit.springboot.RecruitmentWebPortal.serviceimpl;

import com.recruit.springboot.RecruitmentWebPortal.DTO.CreateUserDTO;
import com.recruit.springboot.RecruitmentWebPortal.DTO.EmployeeDTO;
import com.recruit.springboot.RecruitmentWebPortal.entity.Employee;
import com.recruit.springboot.RecruitmentWebPortal.entity.Role;
import com.recruit.springboot.RecruitmentWebPortal.repository.EmployeeRepository;
import com.recruit.springboot.RecruitmentWebPortal.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // Create Recruiter/HR user by Admin
    @Override
    public String createUser(CreateUserDTO dto) {
        if (employeeRepository.findByEmail(dto.getEmail()).isPresent()) {
            return "User with this email already exists.";
        }

        Employee user = new Employee();
        user.setName(dto.getName());
        user.setEmail(dto.getEmail());
        user.setPassword(passwordEncoder.encode(dto.getPassword())); // Secure encoding
        user.setRole(Role.valueOf(dto.getRole().toUpperCase())); // e.g. RECRUITER, HR

        employeeRepository.save(user);
        return "User created successfully.";
    }

    //  Add regular Employee (general CRUD)
    @Override
    public String addEmployee(EmployeeDTO dto) {
        if (employeeRepository.findByEmail(dto.getEmail()).isPresent()) {
            return "Employee with this email already exists!";
        }

        Employee emp = new Employee();
        emp.setName(dto.getName());
        emp.setEmail(dto.getEmail());
        emp.setPassword(dto.getPassword());
        employeeRepository.save(emp);
        return "Employee added successfully!";
    }

    @Override
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    @Override
    public Employee getEmployeeById(Long id) {
        return employeeRepository.findById(id).orElse(null);
    }

    @Override
    public String updateEmployee(Long id, EmployeeDTO dto) {
        return employeeRepository.findById(id).map(emp -> {
            emp.setName(dto.getName());
            emp.setEmail(dto.getEmail());
            emp.setPassword(dto.getPassword());
            employeeRepository.save(emp);
            return "Employee updated!";
        }).orElse("Employee not found!");
    }

    @Override
    public String deleteEmployee(Long id) {
        if (employeeRepository.existsById(id)) {
            employeeRepository.deleteById(id);
            return "Deleted successfully!";
        }
        return "Employee not found!";
    }

    // /Update User (Admin feature)
    @Override
    public String updateUser(Long id, CreateUserDTO dto) {
        return employeeRepository.findById(id).map(user -> {
            user.setName(dto.getName());
            user.setEmail(dto.getEmail());
            user.setRole(Role.valueOf(dto.getRole().toUpperCase()));
            employeeRepository.save(user);
            return "User updated!";
        }).orElse("User not found!");
    }

    // / Delete User (Admin feature)
    @Override
    public String deleteUser(Long id) {
        if (employeeRepository.existsById(id)) {
            employeeRepository.deleteById(id);
            return "User deleted!";
        }
        return "User not found!";
    }
}
