package com.recruit.springboot.RecruitmentWebPortal.entity;

public enum WorkTimings {
    NINE_AM_TO_SIX_PM("9AM-6PM"),
    NINE_THIRTY_AM_TO_SIX_THIRTY_PM("9.30AM-6.30PM"),
    ELEVEN_AM_TO_EIGHT_PM("11AM-8PM"),
    TWO_PM_TO_ELEVEN_PM("2PM-11PM");

    private final String label;

    WorkTimings(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}
